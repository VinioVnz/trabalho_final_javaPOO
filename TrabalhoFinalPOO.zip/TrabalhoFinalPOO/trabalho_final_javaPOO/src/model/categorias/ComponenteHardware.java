package model.categorias;

public class ComponenteHardware extends Categoria{

    public ComponenteHardware() {
        super("Componente de Hardware");

    }
    
}
