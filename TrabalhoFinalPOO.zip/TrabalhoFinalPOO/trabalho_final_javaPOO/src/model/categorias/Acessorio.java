package model.categorias;

public class Acessorio extends Categoria{

    public Acessorio() {
        super("Acessorio");
    }
    
}
