package model.categorias;

public class OutroProduto extends Categoria{

    public OutroProduto() {
        super("Outro produto");

    }
    
}
