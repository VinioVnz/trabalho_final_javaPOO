package model.categorias;

public class Periferico extends Categoria {

    public Periferico() {
        super("Periférico");

    }

}
